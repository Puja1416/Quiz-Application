import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-given-quizzes',
  templateUrl: './user-given-quizzes.component.html',
  styleUrls: ['./user-given-quizzes.component.css']
})
export class UserGivenQuizzesComponent implements OnInit {
  ngOnInit(): void {
    
  }

}
