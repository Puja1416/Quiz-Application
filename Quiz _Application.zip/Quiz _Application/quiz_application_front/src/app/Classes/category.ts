export class Category {
    catId!:Number;
    title!:String;
    description!:String;
}
