export class User {
    userId!:number;
    username!:String;
    password!:String;
    firstName!:String;
    lastName!:String;
    email!:String;
    phone!:String;
    enable!:Boolean;
    profile!:String;
authorities: any;

}
