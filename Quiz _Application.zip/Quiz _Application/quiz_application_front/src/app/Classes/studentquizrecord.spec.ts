import { Studentquizrecord } from './studentquizrecord';

describe('Studentquizrecord', () => {
  it('should create an instance', () => {
    expect(new Studentquizrecord()).toBeTruthy();
  });
});
